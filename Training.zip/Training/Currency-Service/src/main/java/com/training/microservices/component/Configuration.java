package com.training.microservices.component;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
//prefix the variable used in application.prop
@ConfigurationProperties("currency-service")
public class Configuration {
	private int inr;
	private int usd;
	public int getInr() {
		return inr;
	}
	public void setInr(int inr) {
		this.inr = inr;
	}
	public int getUsd() {
		return usd;
	}
	public void setUsd(int usd) {
		this.usd = usd;
	}
	public Configuration(int inr, int usd) {
		super();
		this.inr = inr;
		this.usd = usd;
	}
	public Configuration() {}
	
	@Override
	public String toString() {
		return "Configuration [inr=" + inr + ", usd=" + usd + "]";
	}
	
}
