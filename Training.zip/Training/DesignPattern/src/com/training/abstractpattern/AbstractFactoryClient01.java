package com.training.abstractpattern;

public class AbstractFactoryClient01 {
	public static void main(String[] args) {

		//////////// getColor Factory

		AbstractFactory color = FactoryProducers.getFactory("color");

		IColor blue = color.getColor("blue");
		blue.paintCar();

		IColor red = color.getColor("red");
		red.paintCar();

		///////// get Vechicle Factory

		AbstractFactory vechicle = FactoryProducers.getFactory("vehicle");

		IVehlcle car = vechicle.getVehicle("car");
		car.move();
		car.paint(blue);
		car.speed(100);

		IVehlcle truck = vechicle.getVehicle("truck");
		truck.move();
		car.paint(red);
		truck.speed(100);

	}
}
