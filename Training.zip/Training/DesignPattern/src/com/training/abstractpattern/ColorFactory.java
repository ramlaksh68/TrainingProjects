package com.training.abstractpattern;

public class ColorFactory extends AbstractFactory {

	@Override
	public IVehlcle getVehicle(String vehicle) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IColor getColor(String color) {
		return color.equals("red")?new Red():color.equals("blue")?new Blue():null;
	}

}
