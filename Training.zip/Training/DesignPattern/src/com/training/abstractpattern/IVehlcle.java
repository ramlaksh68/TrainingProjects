package com.training.abstractpattern;

public interface IVehlcle {
 void move();
 void speed(int maxspeed);
 void paint(IColor color);
}



class Car implements IVehlcle{
	

	@Override
	public void move() {
	System.out.println("Car is Moving ");
	}

	@Override
	public void speed(int maxspeed) {
		System.out.println("Max Speed of Car is : "+maxspeed);	
	}

	@Override
	public void paint(IColor color) {
	color.paintCar();
	}
	
}

class Truck implements IVehlcle{

	@Override
	public void move() {
	System.out.println("Truck is Moving ");
	}

	@Override
	public void speed(int maxspeed) {
		System.out.println("Max Speed of Truck is : "+maxspeed);	
	}

	@Override
	public void paint(IColor color) {
	color.paintCar();
	}
	
}