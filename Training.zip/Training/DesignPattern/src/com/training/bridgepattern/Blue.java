package com.training.bridgepattern;

public class Blue implements IColor {

	@Override
	public void applyColor() {
		System.out.println("Painting Blue Color");
	}

}
