package com.training.bridgepattern;

public class BrigdeClient01 {

	public static void main(String[] args) {
		Shape triangle=new Triangle(new Blue());
		triangle.applyColor();
		
		Shape rect=new Rectangle(new Red());
		rect.applyColor();
	}

}
