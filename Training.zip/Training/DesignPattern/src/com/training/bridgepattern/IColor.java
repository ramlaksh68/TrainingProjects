package com.training.bridgepattern;

public interface IColor {

	public void applyColor();
}
