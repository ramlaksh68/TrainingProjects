package com.training.bridgepattern;

public class Red implements IColor {

	@Override
	public void applyColor() {
		System.out.println("Painting Red Color");
	}

}
