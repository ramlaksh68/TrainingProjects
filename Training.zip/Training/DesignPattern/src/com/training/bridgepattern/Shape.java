package com.training.bridgepattern;

//this shall be treated as abstarct class
// since the refrence of the coolor is kept here

//every shape shall have color

public abstract class Shape {

	private IColor color;

	public Shape(IColor color) {
		super();
		this.setColor(color);
	}
	public Shape() {}
	
	public abstract void applyColor();
	
	public IColor getColor() {
		return color;
	}
	public void setColor(IColor color) {
		this.color = color;
	}
}
