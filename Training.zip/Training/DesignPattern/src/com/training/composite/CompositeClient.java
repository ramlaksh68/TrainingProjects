package com.training.composite;

public class CompositeClient {
	public static void main(String[] args) {
		Customer cust1=new Customer(101, "RAMU");
		Customer cust2=new Customer(102, "LAKS");
		Customer cust3=new Customer(103, "SIVA");
		Customer cust4=new Customer(104, "RAJA");
		Customer cust5=new Customer(105, "AMAN");
		Customer cust6=new Customer(106, "PUGAL");
		cust1.addRefernce(cust2);
		cust1.addRefernce(cust3);
		cust1.addRefernce(cust4);
		
		cust2.addRefernce(cust6);
		cust2.addRefernce(cust4);
		
		cust3.addRefernce(cust5);
		
		System.out.println("Print all customer references tree");
		
		System.out.println("Customer Refernce 1");
		cust1.getRefrence().stream().map(Customer::getCustomername).forEach(System.out::println);
		
		System.out.println("Customer Refernce 2");
		cust2.getRefrence().stream().map(Customer::getCustomername).forEach(System.out::println);
		
		System.out.println("Customer Refernce 3");
		cust3.getRefrence().stream().map(Customer::getCustomername).forEach(System.out::println);
	}
}
