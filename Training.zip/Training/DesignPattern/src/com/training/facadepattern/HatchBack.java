package com.training.facadepattern;

public class HatchBack implements ICar {

	@Override
	public void drive() {
		System.out.println("Driving is good in metro city for small famlies");
	}

}
