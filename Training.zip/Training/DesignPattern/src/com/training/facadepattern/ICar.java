package com.training.facadepattern;

public interface ICar {
  void drive();
}
