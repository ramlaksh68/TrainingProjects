package com.training.facadepattern;

public class SUV implements ICar {

	@Override
	public void drive() {
		System.out.println("SUV is good  for off roads and big familes");
	}

}
