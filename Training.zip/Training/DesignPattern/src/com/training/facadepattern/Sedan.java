package com.training.facadepattern;

public class Sedan implements ICar {

	@Override
	public void drive() {
		System.out.println("Sedan is good  for long drives and more boot space");	
		}

}
