package com.training.factory;

public abstract class Car {
	public static Car getCar(CarName carname) {
		if(carname.equals(CarName.MARUTI)) {
			return new Maruti();
		}
		else if(carname.equals(CarName.BMW))  {
			return new BMW();
		}
		return null;
	}
	
	public abstract void drive();
}
