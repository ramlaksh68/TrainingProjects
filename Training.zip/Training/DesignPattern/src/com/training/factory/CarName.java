package com.training.factory;

public enum CarName {
		MARUTI,BMW,AUDI
}
