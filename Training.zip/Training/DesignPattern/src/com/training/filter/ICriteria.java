package com.training.filter;

import java.util.List;

import com.training.statergy.Person;

public interface ICriteria {
	public List<Person> meetCriteria(List<Person> person);
}
