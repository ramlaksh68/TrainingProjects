package com.training.filter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.training.statergy.Person;

public class OrCritria implements ICriteria{
	private ICriteria firstCriteria;
	private ICriteria secCriteria;
	public OrCritria(ICriteria firstCriteria, ICriteria secCriteria) {
		super();
		this.firstCriteria = firstCriteria;
		this.secCriteria = secCriteria;
	}

	@Override
	public List<Person> meetCriteria(List<Person> person) {
		List<Person> fist=firstCriteria.meetCriteria(person);
		List<Person> sewc=secCriteria.meetCriteria(person);
		Set<Person> orList=new HashSet<>(fist);
		orList.addAll(sewc);
		return new ArrayList<>(orList);
	}
}
