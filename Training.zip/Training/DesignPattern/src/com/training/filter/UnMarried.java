package com.training.filter;

import java.util.ArrayList;
import java.util.List;

import com.training.statergy.Person;

public class UnMarried implements ICriteria {

	@Override
	public List<Person> meetCriteria(List<Person> person) {
		List<Person> maleList=new ArrayList<>();
		for(Person per:person)
			if(per.getMartialstatus().equals("unmarried"))maleList.add(per);
		return maleList;
	}

}
