package com.training.mvc;

public class StarView implements Views{

	public void printEmployee(Employee emp) {
		System.out.println("******************************************");
		System.out.println("Emplyee id :"+emp.getEmpid());
		System.out.println("Emplyee id :"+emp.getEmpname());
		System.out.println("******************************************");
	}
}
