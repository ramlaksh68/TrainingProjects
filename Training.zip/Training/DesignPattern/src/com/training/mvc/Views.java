package com.training.mvc;

public interface Views {
	void printEmployee(Employee emp);
}
