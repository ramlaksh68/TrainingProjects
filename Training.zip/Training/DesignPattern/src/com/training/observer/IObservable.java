package com.training.observer;

//on which the observer is interested 
public interface IObservable {
	void addUser(IObserver obs);
	void remove(IObserver obs);
	 String printClassName();
	//all the people who are all in the list
	void notifyObserver();
}
