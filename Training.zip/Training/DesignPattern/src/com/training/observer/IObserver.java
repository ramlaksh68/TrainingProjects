package com.training.observer;


//refres to user 
public interface IObserver {
	public void update();
}
