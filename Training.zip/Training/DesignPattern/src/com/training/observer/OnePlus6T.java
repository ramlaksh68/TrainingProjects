package com.training.observer;

import java.util.ArrayList;
import java.util.List;

public class OnePlus6T implements IObservable {

	private List<IObserver> user;
	private boolean isArrived;

	OnePlus6T() {
		user = new ArrayList<>();
	}
	@Override
	public void addUser(IObserver obs) {

		user.add(obs);
	}

	@Override
	public void remove(IObserver obs) {

		user.remove(obs);
	}

	@Override
	public void notifyObserver() {
		// to notify all user
		user.forEach(a->a.update());
		
	}
	
	public boolean isArrived() {
		return isArrived;
	}

	public void setArrived(boolean isArrived) {
		this.isArrived = isArrived;
		notifyObserver();
	}
	@Override
	public String printClassName() {
		// TODO Auto-generated method stub
		return this.getClass().getSimpleName();
	}

}
