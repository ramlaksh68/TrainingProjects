package com.training.observer;


public class User implements IObserver {
	
	private IObservable observable=null;
	private String name;
	
	
	public User(IObservable observable, String name) {
		super();
		this.observable = observable;
		this.name = name;
	}

	public void buyMobile() {
		System.out.println("Hurry, I`HAVE bopught "+ observable.printClassName() +" ,by "+name);
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		buyMobile();
	}

	public void unSubscribe() {
		observable.remove(this);
	}
	
	
}
