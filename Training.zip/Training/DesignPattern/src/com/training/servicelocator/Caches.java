package com.training.servicelocator;

import java.util.ArrayList;
import java.util.List;

public class Caches {
	private List<Service> services;
	Caches(){
		services=new ArrayList<>();
	}
	
	public Service getService(String serviceName) {
		for(Service ser:services) {
			if(ser.getName().equalsIgnoreCase(serviceName)) {
				return ser;
			}
		}
		return null;
	}
	
	public void addService(Service service) {
		boolean exst=false;
		for(Service ser:services) {
			if(ser.getName().equalsIgnoreCase(service.getName())) {
				exst=true;
			}
		}
		if(!exst)services.add(service);
	}
	
	
}
