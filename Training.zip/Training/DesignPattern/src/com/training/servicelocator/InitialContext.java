package com.training.servicelocator;

public class InitialContext {
	public Service lookup(String jndiName) {
		if(jndiName.equalsIgnoreCase("DBService")){
			System.out.println("Created db");
			return new DBService();
			
			}
		else if(jndiName.equalsIgnoreCase("ERB Service")) {
			System.out.println("Created erb");
			return new ERBService();
		}
		else return null;
	}
}
