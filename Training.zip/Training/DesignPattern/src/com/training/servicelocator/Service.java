package com.training.servicelocator;

public interface Service {

	String getName();
	void excute();	
}
