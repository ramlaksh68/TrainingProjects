package com.training.singleton;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class SingletonClient04 {
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		Singleton singlton = Singleton.getInstance();
		
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("Singleton.ser"));
		out.writeObject(singlton);
		System.out.println("Object saved with hashCode of : "+singlton.hashCode());
		out.close();
		
		
		ObjectInputStream in = new ObjectInputStream(new FileInputStream("Singleton.ser"));
		Singleton cpusingleton=(Singleton) in.readObject();
		System.out.println("After retrived Object with hashCode of : "+cpusingleton.hashCode());
		in.close();
	}
}
