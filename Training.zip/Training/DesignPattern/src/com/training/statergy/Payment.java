package com.training.statergy;

public interface Payment {
	void pay(int amount);
}
