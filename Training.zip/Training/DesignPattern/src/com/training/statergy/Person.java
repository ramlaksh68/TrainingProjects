package com.training.statergy;

import java.util.Objects;

public class Person {

	private String name;
	private String sex;
	private String martialstatus;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getMartialstatus() {
		return martialstatus;
	}
	public void setMartialstatus(String martialstatus) {
		this.martialstatus = martialstatus;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", sex=" + sex + ", martialstatus=" + martialstatus + "]";
	}
	public Person() {}
	public Person(String name, String sex, String martialstatus) {
		super();
		this.name = name;
		this.sex = sex;
		this.martialstatus = martialstatus;
	}
	@Override
	public int hashCode() {
		return Objects.hashCode(name+sex+martialstatus);
	}
	@Override
	public boolean equals(Object obj) {
		Person per=(Person)obj;
		return (martialstatus.equals(per.martialstatus)&&name.equals(per.name)&&sex.equals(per.sex));
		}
	
}
