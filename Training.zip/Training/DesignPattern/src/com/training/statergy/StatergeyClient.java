package com.training.statergy;

import java.util.Arrays;
import java.util.List;

import com.training.filter.Item;

public class StatergeyClient {
	public static void main(String[] args) {
		List<Item> items=Arrays.asList(new Item("Mobile",30,4),
				new Item("Fridge",50,9),
				new Item("Tv",770,8),
				new Item("Own",450,12),
				new Item("Ac",340,7)				
				);
		
		ShoppingCard scard=new ShoppingCard();
		items.forEach(scard::addItem);
		
		System.out.println("-------- Modification----------");
		scard.modeifyItem(new Item("Fridge",50,20));
		
		System.out.println("TOtal AMount "+scard.calculateTotal());
		Payment payment=new EWallet("abc@gmail.com", "12345", "paytm");
		
		
		scard.checkOut(payment);
	} 
}
