package com.java8;

import java.util.List;

public class Detail {

	private int detailId;
	private Double price;
	private List<String> parts;
	
	public Detail(int detailId, List<String> parts) {
		super();
		this.detailId = detailId;
		this.parts = parts;
	}

	public Detail() {
		
	}

}
