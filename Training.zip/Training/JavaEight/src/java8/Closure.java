package java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

interface ClosureInterface {
    void speak();
}


public class Closure {
	public static void main(String[] args) {
		int k=0;
    	 Comparator cmp=(obj1,obj2)->{
    	  	   System.out.println(k); ///////////closure mean it can access out side method varaibles but we cannot change the value
    	  	   return obj1.toString().compareTo(obj2.toString());
    	     };
    }
}