package java8;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import static java.lang.System.out;
import static  java.util.Comparator.*;
public class Comparators {

	public static void main(String[] args) {
		 List<Product> productsList = new ArrayList<Product>();  
	        //Adding Products  
	        productsList.add(new Product(1,"HP Laptop",25000f));  
	        productsList.add(new Product(2,"Dell Laptop",30000f));  
	        productsList.add(new Product(3,"Lenevo Laptop",28000f));  
	        productsList.add(new Product(4,"Sony Laptop",28000f));  
	        productsList.add(new Product(5,"Apple Laptop",90000f));  
	        productsList.stream().sorted(comparing(Product::getPrice)
	        		.thenComparing(Product::getName)).forEach(out::println);
	}
}
