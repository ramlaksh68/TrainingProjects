package java8;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;

public class DateTime {

	public static void main(String[] args) {
		LocalDate date=LocalDate.now();
		System.out.println(date);
		///////////Local Date is thread Safe
		System.out.println(LocalDate.parse("2017-09-13").isBefore(LocalDate.parse("2017-09-15")));
		
		System.out.println(LocalDate.parse("2017-09-15").isAfter(LocalDate.parse("2017-09-13")));
		
		
		System.out.println("First Day Of Month = "+date.with(TemporalAdjusters.firstDayOfMonth()));
		System.out.println("Last Day Of Month = "+date.with(TemporalAdjusters.lastDayOfMonth()));
		
		System.out.println("Next Date of GIven Period = "+date.plus(Period.ofDays(26)));	
		
	}
}
