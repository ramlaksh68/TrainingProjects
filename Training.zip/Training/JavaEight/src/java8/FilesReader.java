package java8;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class FilesReader {
public static void main(String[] args) {
	Path path=Paths.get("test.txt");
	try (Stream<String> file=Files.lines(path)){
		file.forEach(System.out::println);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
