package java8;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.java8.Detail;

public class FlatMap {

	public static void main(String[] args) {

		List<String> uris = new ArrayList<>();
		uris.add("C:\\Myfile1.txt");
		uris.add("D:\\Myfile2.txt");
		uris.add("C:\\Myfile3.txt");
		
		Stream<Path> map = uris.stream().map(Paths::get);
		map.forEach(System.out::println);
		
		System.out.println("-------------------------");
		
		List<Detail> details =new ArrayList<>();
		
		List<String> parts1 = new ArrayList<>();
		parts1.add("Parts_1");
		parts1.add("Part_2");
		parts1.add("Part_3");
		
		List<String> parts2 = new ArrayList<>();
		parts2.add("Part_1");
		parts2.add("Part_2");
		parts2.add("Part_1");
		parts2.add("Part_4");
		Detail detail1= new Detail(1001, parts1);
		Detail detail2= new Detail(1002, parts2);
		
		details.add(detail1);
		details.add(detail2);
		
		parts2.stream().forEach(FlatMap::dispaly);

		 System.out.println("-------------------------");
		 
		 String joint=parts1.stream().reduce("",(x,y)->x+y);
		 System.out.println(joint);
		 
		 
		 
		 
	}
	
	public static void dispaly(String... data) {
		data[0]=data[0].toUpperCase();
		System.out.println(data);
	}
}


