package java8;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FunctionCombination {
	
//////////// Custom Filter By Name
	BiFunction<String,List<Product>,List<Product>> flterBYName=(name,list)->{
				return list.stream().filter(pdt->pdt.name==name).collect(Collectors.toList());
			};
///////////  Custom Filters By Id
	BiFunction<String,List<Product>,List<Product>> flterBYId=(id,list)->{
				return list.stream().filter(pdt->pdt.name==id).collect(Collectors.toList());
			};
			
	public static Integer sumOftwo(Integer a) {
		return a+5;
	}
public static void main(String[] args) {
	Function<Integer,Integer> sum=FunctionCombination::sumOftwo;
		Function<Integer,Integer> mult=(data)->{
		return data*data; 
	};
	
	System.out.println("Compose Of "+sum.compose(mult).apply(5));
	System.out.println("AndThen Of "+sum.andThen(mult).apply(5));
	//////////
	
	
	 Consumer<String> c = (x) ->{ 
		 System.out.println(x.toLowerCase());
		 };
	 c.andThen(c).accept("Java2s.com");
	
	//////// Second Example 
	
	   List<Product> productsList = new ArrayList<Product>();  
       //Adding Products  
       productsList.add(new Product(1,"HP Laptop",25000f));  
       productsList.add(new Product(2,"Dell Laptop",30000f));  
       productsList.add(new Product(3,"Lenevo Laptop",28000f));  
       productsList.add(new Product(4,"Sony Laptop",28000f));  
       productsList.add(new Product(5,"Apple Laptop",90000f));  
       FunctionCombination fb=new FunctionCombination();
      // System.out.println("ID AND NAME"+fb.flterBYId.andThen(fb.flterBYName).apply());
       
	}
}
