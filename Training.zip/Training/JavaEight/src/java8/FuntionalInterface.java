package java8;

import java.util.Arrays;
import java.util.List;

public class FuntionalInterface {
public static void main(String[] args) {
	MessageDeliver obj=System.out::println;;
	obj.delivery("1");
	
}
public static void methodReference() {
	System.out.println("Method Reference Working");
}
}

interface MessageDeliver{
	public void delivery(String sm);
}