package java8;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import static java.lang.System.out;
import static java.util.stream.Collectors.*;
public class InfiniteStream {

	public static void main(String[] args) {
		Stream.of("Ram","lak","kum","hu").forEach(out::println);
		System.out.println("-----------------");
		Stream.generate(InfiniteStream::random).limit(6).forEach(out::println);
		System.out.println("-----------------");
	
	Stream.iterate(2, e->e+1).flatMap(i->IntStream.range(1, i). /////////Pitha gross
			mapToObj(n->getPithogrss(i, n))).limit(10).forEach(out::println);
	
	out.println("------------------------- get the prime-------------------");
	
	IntStream.rangeClosed(1,100).filter(new InfiniteStream()::isPrime).forEach(out::println);;
	
	out.println("------------------------- get the sqrt of prime-------------------");
	
	double sumofPrimeSqt=IntStream.rangeClosed(1,100).filter(new InfiniteStream()::isPrime).mapToDouble(i->Math.sqrt(i)).sum();
	out.print(sumofPrimeSqt);
	
	}
	
	
	public static String random() {
		return ""+new Random();
		
	}
	public static String getPithogrss(int m,int n) {
		int a=m*m-n*n;
		int b=2*m*n;
		int c=m*m+n*n;
		return String.format("%d %d %d", a,b,c);
	}
	
	public boolean isPrime(int num) {
		return (1<num&&IntStream.range(2,num).noneMatch(i->num%i==0));
	}
}
