package java8;

import java.util.function.Function;
import java.util.function.IntFunction;

public class LambdaReference {
	 Calculator cl=(i)->System.out.println(i+" "+this);  /////this is refer the LamdaExpression Class
	 
	  public static void main(String[] argv) {
		  LambdaReference lm=new LambdaReference();
	  lm.cl.calculate("Hi");
	  Calculator clinner=new Calculator() {
		
		@Override
		public void calculate(String data) {
			System.out.println(data+" "+this); /////this is refer the calcuator Class
		}
		@Override
		public String toString() {
			return "Calulate";
			
		}
	};
	clinner.calculate("Hi");
	  }
	  @Override
		public String toString() {
			return "LamdaClass";
			
		}
	}

	@FunctionalInterface
	interface Calculator{
	  void calculate(String data);
	}

	