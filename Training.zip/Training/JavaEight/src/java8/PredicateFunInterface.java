package java8;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Stream;

import static java.lang.System.out;
public class PredicateFunInterface {

	 
		public static void main(String[] args) {

			  List<Product> productsList = new ArrayList<>();  
		        //Adding Products  
		        productsList.add(new Product(1,"HPf Laptop",25000f));  
		        productsList.add(new Product(2,"Dell Laptop",30000f));  
		        productsList.add(new Product(3,"HP Laptop",28000f));  
		        productsList.add(new Product(4,"HP Laptop",28000f));  
		        productsList.add(new Product(5,"Apple Laptop",90000f));  
		        
		        Predicate<Product> pre=Product::isAvgSalery;
		        productsList.stream().filter(pre).forEach(out::println);
		        
		        
		        Consumer<Product> toUpperCase=obj->{
		        	out.println("Going For To Upper Case");
		        	obj.setName(obj.getName().toUpperCase()); 	
		        	out.println("After Upper Case " + obj.getName());
		        	};
		        	Consumer<Product> joinWord=obj->{
			        	out.println("Going For Join Words");
			        	obj.setName(String.join("",obj.getName().split(" ")));
					out.println("After Join " + obj.getName());
			        	};
		        productsList.stream().forEach(toUpperCase.andThen(joinWord));
		        
		        Supplier <Product> sup=Product::new;
		        Stream.generate(sup).limit(10).forEach(out::println);
		}
}
