package java8;

import java.util.function.Function;

public class Scopes {
	int nonlocalvar=10; 
	public Scopes(){
	    // 1.  int x= 0; we cannot use same varaiable which refres to the arg in lambda expression 
		// int y=10;
	    Function<String,String> func1 = x -> {System.out.println(this);
	    //	    y=15;  2.  we cannot change outside variable inside lambda expression 
	    nonlocalvar=20; ////  3.   we can change non local variables;
	    for(int i=0;i<10;i++) {
	    	if(i==5)break; //////its Possible ....
	    }
//	    for(int i=0;i<10;i++) {
//	    	  Function<String,String> func3 = y -> { break; 
	    //return "Hi";}; //////  4.   its Not Possible ....
//	    }
	    return x ;
	    };
	    System.out.println(func1.apply("Meth"));
	  }
	  public String toString(){
	    return "Scope";
	  }
	  public static void main(String[] argv) {
	    new Scopes();
	  }
	}

