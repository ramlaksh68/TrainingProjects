package java8;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;
import static java.lang.System.out;
import static java.util.stream.Collectors.groupingBy;
public class StaticImport {

	public static void main(String[] args) {
		
		Map<String,Integer> studntwithRank=new HashMap<String,Integer>();
		studntwithRank.put("ram", 2);
		studntwithRank.put("laksh", 1);
		studntwithRank.put("siva", 1);
		studntwithRank.put("usk", 1);
		studntwithRank.put("raja", 2);
		
		out.println("Get The Grouping Result By Stream And Static Import");
		
		out.println(studntwithRank.keySet().stream()
		.collect(groupingBy(studntwithRank::get))); ////////////// here we are doing staic import 
		IntStream.rangeClosed(1,100).forEach(out::println); ///////
	}

}
