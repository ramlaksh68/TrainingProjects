package com.tarining;

import static java.lang.System.out;

import java.util.HashMap;
import java.util.Map;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

public class StoreEmpRecord {
	static  MongoClient mongoClient=new MongoClient();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 DB db=mongoClient.getDB("exdb");
		 DBCollection dbCollection=db.getCollection("emps");
		 
		 //// 111 way
		 
		 
//		 DBObject  empObj=new BasicDBObject();
//		 empObj.put("empid", 110);
//		 empObj.put("empnm", "maran");
//		 empObj.put("empsalary",4500);
//		 dbCollection.insert(empObj);
		 
		
		 //// 222 way
		 
//		 
//		 Map<String,Object>  empObj=new HashMap<>();
//		 empObj.put("empid", 111);
//		 empObj.put("empnm", "kavi");
//		 empObj.put("empsalary",7500);
//		 empObj.put("empemail","kavi@gmail.com");
//		 dbCollection.insert(new BasicDBObject(empObj));
		 
		 //// 333 way
		 
//		 String jsonString ="{empid : 112 , empsalary : 7800 , empnm: 'abi', empemail : 'abi@gmail.com'}";
//		 dbCollection.insert((DBObject)JSON.parse(jsonString));
		 
		 
		 //// 444 way
		 
		 Employee emp=new Employee(118, "rakku", 2300d, "raku@gmail.com");
		 dbCollection.insert((DBObject)emp);
		 
		 ///where empid eq 105
		 dbCollection.find().forEach(out::println);
		 
		 
	
	}


}
