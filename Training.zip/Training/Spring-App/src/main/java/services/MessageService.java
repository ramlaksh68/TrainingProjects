package services;

import java.io.Serializable;

import org.springframework.stereotype.Service;
@Service
public class MessageService implements Serializable {

	public void sendMessage(String msg) {
		System.out.println(msg);
	}
	
	
}
