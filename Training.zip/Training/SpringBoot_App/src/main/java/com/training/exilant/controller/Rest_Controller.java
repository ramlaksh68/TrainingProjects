package com.training.exilant.controller;

import java.net.URI;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import static  org.springframework.hateoas.mvc.ControllerLinkBuilder.*;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.hateoas.mvc.ControllerLinkBuilderFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.training.exilant.Entity.HelloWorld;
import com.training.exilant.Entity.User;
import com.training.exilant.controller.service.UserService;
import com.training.exilant.exception.UserNotFoundException;

@RestController
@RequestMapping("api")
public class Rest_Controller {

	
	@Autowired
	UserService userService;
	
	public UserService getUserService() {
		return userService;
	}


	public void setUserService(UserService userService) {
		this.userService = userService;
	}


	@GetMapping("/welcome/string")
	public String getWelcomeMessage() {
		return "Welcome New User"; 
	}
	
	
	@GetMapping("/welcome/bean")
	public HelloWorld getWelcomeMessageFromEntity() {
		return new HelloWorld("Welcome New User"); 
	}
	
	@GetMapping("/welcome/path/{name}")
	public HelloWorld helloMessagePathVariable(@PathVariable("name") String name) {
		return new HelloWorld("Welcome New User----->"+name); 
	}
	
	@GetMapping("/user")
	public List<User> getAllUserList() {
		return userService.getAllUserList(); 
	}
	
//	@GetMapping("/user/{id}")
//	public ResponseEntity<Object> getAllUserList(@PathVariable("id") Integer id) {
//		User user=userService.getOneUser(id); 
//		if(user!=null)
//		return ResponseEntity.accepted().body(user);
//		else
//			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No User Found For Given Id-->"+id);	
//	}
	
	
	@GetMapping("/user/{id}")
	public User getOneUser(@PathVariable("id") Integer id) throws UserNotFoundException {
		User user=userService.getOneUser(id); 
		if(user==null)
		throw new UserNotFoundException("No User Found For Given Id-->"+id);
		else
			return user;	
	}
	
	//will give user+give the reference links to the caller with additional links
	@GetMapping("/userv2/{id}")
	public Resource<User> getOneUserVersion2(@PathVariable("id") Integer id) throws UserNotFoundException {
		User user=userService.getOneUser(id); 
		if(user==null)
		throw new UserNotFoundException("No User Found For Given Id-->"+id);
		
		//give the link for all users
		//with meta data all uyser  with server path +/users
		
		Resource<User> resource= new Resource<User>(user);
		
		ControllerLinkBuilder linkForAll =new ControllerLinkBuilderFactory().linkTo(methodOn(this.getClass()).getAllUserList());
		ControllerLinkBuilder linkForOne =new ControllerLinkBuilderFactory().linkTo(methodOn(this.getClass()).getOneUser(id));
		resource.add(linkForAll.withRel("all-users"));
		resource.add(linkForOne.withRel("single-users"));
		return resource;	
	}
	
	@PostMapping("/user")
	public ResponseEntity<Object> createUser(@RequestBody User user) {
		User updateUser=userService.saveUser(user); 
		URI uri=ServletUriComponentsBuilder.fromCurrentRequest().path("/{userid}").buildAndExpand(updateUser.getUserid()).toUri();
		return ResponseEntity.created(uri).build();
	}
	
	
	@PostMapping("/userv2")
	public Resource<String> createUserVersion2(@RequestBody User user) throws UserNotFoundException {
		User updateUser=userService.saveUser(user); 
		Resource<String> resource= new Resource<String>("User Created Successfully");
		
		ControllerLinkBuilder linkForUser=new ControllerLinkBuilderFactory().linkTo(methodOn(this.getClass()).getOneUser(updateUser.getUserid()));
		resource.add(linkForUser.withRel("for-user-detail"));
		return resource;
	}
	
	
	
	@PutMapping("/user")
	public ResponseEntity<List<User>> updateUser(@RequestBody User user) {
		List<User>userList=userService.updateUser(user,user.getUserid()); 
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(userList);
	}
	
	
	@DeleteMapping("/user/{id}")
	public List<User> deleteUser(@PathVariable("id") Integer id) {
		return userService.deleteUser(id); 
	}
}
