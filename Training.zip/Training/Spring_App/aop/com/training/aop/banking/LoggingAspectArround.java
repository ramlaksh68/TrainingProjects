package com.training.aop.banking;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class LoggingAspectArround {

	
	@Around("execution(public * get*())")
	public Object sampleArround(ProceedingJoinPoint jp) throws Throwable {
		
		Object retVal=null;
		
		System.out.println("Before Job Goes Here");
		
		retVal=jp.proceed();
		
		System.out.println("After Job Goes Here");
		
		return retVal;
	}
}
