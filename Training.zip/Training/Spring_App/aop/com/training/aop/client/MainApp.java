package com.training.aop.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.aop.model.CAAccount;
import com.training.aop.service.BankingService;


public class MainApp {

	public static void main(String[] args) {
		ApplicationContext contexts =new ClassPathXmlApplicationContext("spring-aop.xml");
		BankingService service=contexts.getBean("bankingService",BankingService.class);
		
		System.out.println(service.getSbaccount().getAccount().getAccName());
		System.out.println(service.getCaaccount().getAccount().getAccName());
	//	System.out.println("\n Word="+service.setAndGet("RAMU.M"));
//		service.getSbaccount().getAccount().setAccName("SIVAAA");
//		service.getCaaccount().getAccount().setAccName("SIVAAA");
//		service.getCaaccount().getOneParameter(100);
	}
	
	
}
