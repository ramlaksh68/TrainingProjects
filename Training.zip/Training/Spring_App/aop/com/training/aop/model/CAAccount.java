package com.training.aop.model;

public class CAAccount {
	private Account account;

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
	
	void getTest() {
		System.out.println("This is default test.....");
	}
	
	public void getOneParameter(int x) {
		System.out.printf("given value %d",x);
	}
	public Double showBalance() {
		this.getTest();
		return account.getBalance();
	}
}
