package com.training.aop.service;

import com.sun.javafx.binding.StringFormatter;
import com.training.aop.model.CAAccount;
import com.training.aop.model.SBAccount;

public class BankingService {
	private SBAccount sbaccount; 
	private CAAccount caaccount;
	public SBAccount getSbaccount() {
		return sbaccount;
	}
	public void setSbaccount(SBAccount sbaccount) {
		this.sbaccount = sbaccount;
	}
	public CAAccount getCaaccount() {
	//	if(1==1)System.out.println(1/0);
		return caaccount;
	}
	public void setCaaccount(CAAccount caaccount) {
		this.caaccount = caaccount;
	}
	@Override
	public String toString() {
		return "BankingService [sbaccount=" + sbaccount + ", caaccount=" + caaccount + "]";
	}
	
	public String setAndGet(String name) {
		return String.format("hello %s welcome", name);
	}
}

