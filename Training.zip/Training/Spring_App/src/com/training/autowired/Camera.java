package com.training.autowired;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Camera {
	@Value("${camera.type}")
	private String type;

	Camera(){
		System.out.println("creating camera "+this);
	}
	
	@Override
	public String toString() {
		return "Camera [type=" + type + "]";
	}

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Camera(String type) {
		super();
		this.type = type;
	}
	
}
