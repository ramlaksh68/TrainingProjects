package com.training.autowired;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.ClassPathResource;
@ComponentScan
@Configuration
public class Configurations {
@Bean(name="mobile")
public Mobile getBeanOfMobile() {
	return new Mobile();
}


@Bean(name="proprty")
public PropertyPlaceholderConfigurer getBeanOfPrptyPlceHolder() {
	PropertyPlaceholderConfigurer prty= new PropertyPlaceholderConfigurer();
	prty.setLocation(new ClassPathResource("mobiles.properties"));
	return prty;
}
}
