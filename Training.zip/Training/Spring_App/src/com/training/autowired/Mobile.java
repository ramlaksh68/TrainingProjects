package com.training.autowired;

import org.springframework.beans.factory.annotation.Autowired;

public class Mobile {
	@Autowired
	private Camera camera;
	@Autowired
	private Speaker speaker;
	@Autowired
	private Screen screen;
	@Override
	public String toString() {
		return "Mobile [camera=" + camera + ", speaker=" + speaker + ", screen=" + screen + "]";
	}
	public Camera getCamera() {
		return camera;
	}
	public void setCamera(Camera camera) {
		this.camera = camera;
	}
	public Speaker getSpeaker() {
		return speaker;
	}
	public void setSpeaker(Speaker speaker) {
		this.speaker = speaker;
	}
	public Screen getScreen() {
		return screen;
	}
	public void setScreen(Screen screen) {
		this.screen = screen;
	}
	public Mobile() {
		System.out.println("creating mobile "+this);
	}
	public Mobile(Camera camera, Speaker speaker, Screen screen) {
		super();
		this.camera = camera;
		this.speaker = speaker;
		this.screen = screen;
	}
	
}
