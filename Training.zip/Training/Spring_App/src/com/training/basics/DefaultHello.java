package com.training.basics;

import java.util.stream.Stream;

public class DefaultHello implements HelloService{

	
	private String name;
	private String city;
	
	
	@Override
	public String toString() {
		return "DefaultHello [name=" + name + ", city=" + city + "]";
	}

	public DefaultHello(String city) {
		super();
		this.city = city;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	DefaultHello(){
		
	}
	
	@Override
	public String sayHello() {
		
		return sayHello(this.name, this.city);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String sayHello(String name, String city) {
		String msg[]={"hey mr/mrs/miss.... %s welcome %s","How are you mr/mrs/miss %s welcome our city %s"};
		int rndm=(int)(Math.random()*2);
		return String.format(msg[rndm], name,city);
	}
	public void ginit() {
		System.out.println("Init for Global HelloWorld");
	}
	
	
	public void gdestroy() {
		System.out.println("Destroy for Global HelloWorld" );
	}
}
