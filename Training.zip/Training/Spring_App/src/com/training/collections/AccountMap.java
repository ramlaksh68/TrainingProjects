package com.training.collections;

import java.util.Map;

public class AccountMap {
	private Map<String,Long> accoutnMap;

	public Map<String, Long> getAccoutnMap() {
		return accoutnMap;
	}

	@Override
	public String toString() {
		return "AccountMap [accoutnMap=" + accoutnMap + "]";
	}

	public void setAccoutnMap(Map<String, Long> accoutnMap) {
		this.accoutnMap = accoutnMap;
	}
	
}
