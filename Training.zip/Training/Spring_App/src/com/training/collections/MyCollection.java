package com.training.collections;

import java.util.List;
import java.util.Set;

public class MyCollection {
	QuestionBank questionBank;
	AddressSet addressSet;
	AccountMap accoutMap;
	public QuestionBank getQuestionBank() {
		return questionBank;
	}
	public void setQuestionBank(QuestionBank questionBank) {
		this.questionBank = questionBank;
	}
	public AddressSet getAddressSet() {
		return addressSet;
	}
	public void setAddressSet(AddressSet addressSet) {
		this.addressSet = addressSet;
	}
	
	public AccountMap getAccoutMap() {
		return accoutMap;
	}
	public void setAccoutMap(AccountMap accoutMap) {
		this.accoutMap = accoutMap;
	}
	@Override
	public String toString() {
		return "MyCollection [questionBank=" + questionBank + ", addressSet=" + addressSet + ", accoutnMap="
				+ accoutMap + "]";
	}
	
	
}
