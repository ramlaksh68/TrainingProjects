package com.training.entity;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDao implements IEmployeeDAO {
	@Autowired
	private DataSource dataSource;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private EmployeeMapper mapper;
	
	
	
	
	public EmployeeMapper getMapper() {
		return mapper;
	}

	public void setMapper(EmployeeMapper mapper) {
		this.mapper = mapper;
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	@Override
	public Employee getEmployee(int empid) {
		String sql="select * from employee where empid=?";
		jdbcTemplate.queryForObject(sql, new Object[] {empid}, mapper);
		System.out.println("Record created successfully");
		return null;
	}

	@Override
	public List<Employee> getAllEmpList() {
		List<Employee> emplist=jdbcTemplate.queryForList("select * from employee", Employee.class);
		return emplist;
	}

	@Override
	public void insertEmployye(Employee emp) {
		// TODO Auto-generated method stub
			String sql="insert into employee (empid,empnm,empsalary) values (?,?,?)";
			jdbcTemplate.update(sql,emp.getEmpid(),emp.getEmpnm(),emp.getEmpsalary());
			System.out.println("Record created successfully");
	}

	@Override
	public void updateEmployee(Employee employee) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setDataSource(DataSource dataSource) {
		this.dataSource=dataSource;
		this.jdbcTemplate=new JdbcTemplate(this.dataSource);
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

}
