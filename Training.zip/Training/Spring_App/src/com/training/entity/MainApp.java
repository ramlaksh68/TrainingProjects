package com.training.entity;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-db.xml");
		EmployeeDao empDao = context.getBean("employeeDao", EmployeeDao.class);
		List<Employee>emplist=Stream.of(new Employee(100, "Ramu", 3000),
		new Employee(101, "Laksh", 3000),
		new Employee(102, "Siva", 3000),
		 new Employee(103, "Raja", 3000)).collect(Collectors.toList());
		
		emplist.forEach(empDao::insertEmployye);
		
		System.out.println(empDao.getEmployee(1));
		
		
		empDao.getAllEmpList().forEach(System.out::println);
	}

}
