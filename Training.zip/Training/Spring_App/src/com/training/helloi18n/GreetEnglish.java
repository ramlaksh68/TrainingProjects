package com.training.helloi18n;

public class GreetEnglish implements Greeting {

	@Override
	public String greetHello() {
		// TODO Auto-generated method stub
		return "Hello World";
	}

}
