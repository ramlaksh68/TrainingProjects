package com.training.profile;

import javax.activation.DataSource;

public interface DataBaseConfig {
	DataSource createDataSource();
}
