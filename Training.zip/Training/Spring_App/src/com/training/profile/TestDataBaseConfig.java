package com.training.profile;

import javax.activation.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

// Test is 
@Configuration
@Profile("Testing")

public class TestDataBaseConfig implements DataBaseConfig {

	@Override
	@Bean(name="dataSource")
	public DataSource createDataSource() {
		System.out.println("Creating Testing Db Instance");
		
		//		you can set parameter
		
		return null;
	}

}
