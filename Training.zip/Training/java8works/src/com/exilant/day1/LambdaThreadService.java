package com.exilant.day1;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class LambdaThreadService {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		System.out.println("------------java 7 way ---------------------");
		ExecutorService excutorService1 = Executors.newSingleThreadExecutor();
		excutorService1.execute(new Runnable() {
			@Override
			public void run() {
				System.out.println("Hi i am Java 7 Anoymnous Function");
			}
		});
		excutorService1.shutdown();
		
		
		System.out.println("------------java 8 way ---------------------");
		ExecutorService excutorService2 = Executors.newSingleThreadExecutor();
		excutorService2.execute(() -> System.out.println("Hi i am Java 8 Anoymnous Function"));
		excutorService2.shutdown();
		
		System.out.println("------------Callable Work Java 8 way ---------------------");
		
		ExecutorService excutorService3 = Executors.newSingleThreadExecutor();
		String result=excutorService3.invokeAny(initializeCallable());
		System.out.println("Result is : "+result);
		
	    List<Future<String>> resultall=excutorService3.invokeAll(initializeCallable());
	    for(Future<String> res:resultall) {
	    	System.out.println("Result all is : "+res.get());
	    }
	    excutorService3.shutdown();
	}

	public static Set<Callable<String>> initializeCallable() {
		Set<Callable<String>> callables = new HashSet<Callable<String>>();
		callables.add(() -> "Caller 1");
		callables.add(() -> "Caller 2");
		callables.add(() -> "Caller 3");
		callables.add(() -> "Caller 4");
		callables.add(() -> "Caller 5");
		callables.add(() -> "Caller 6");
		callables.add(new Callable<String>() {

			@Override
			public String call() throws Exception {
				return "Caller 7";
			}

		});
		return callables;
	}
}
