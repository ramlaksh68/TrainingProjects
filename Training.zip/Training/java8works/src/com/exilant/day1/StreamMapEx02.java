package com.exilant.day1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


//to show working of map and filter on customer type

public class StreamMapEx02 {

	public static List<PriorityCustomer> filterCustomer(List<Customer> customers) {
		List<PriorityCustomer> prioritycustomers = new ArrayList<>();
		for (Customer customer : customers) {
			String type = customer.getCustomerNamePurchases() <= 5000 ? "SILVER"
					: customer.getCustomerNamePurchases() <= 6000 ? "GOLD" : "PLATINUM";
			prioritycustomers.add(new PriorityCustomer(customer.getCustomerId(), customer.getCustomerName(), type));

		}
		return prioritycustomers;
	}

	public static void main(String[] args) {
		List<Customer> customers = Arrays.asList(new Customer(101, "Ramu", 6000d, "Engineer"),
				new Customer(101, "Pooja", 6500d, "Developer"), new Customer(101, "Allahraka", 7500d, "Lead"),
				new Customer(101, "Anuj", 5600d, "Engineer"), new Customer(101, "Siva", 4000d, "Developer"));

		System.out.println("------------------- before java 1.8---------------");

		filterCustomer(customers).forEach(System.out::println);

		System.out.println("------------------- After java 1.8 way  1 ---------------");
		customers.stream().map((customer) -> {
			String type = customer.getCustomerNamePurchases() <= 5000 ? "SILVER"
					: customer.getCustomerNamePurchases() <= 6000 ? "GOLD" : "PLATINUM";
			return new PriorityCustomer(customer.getCustomerId(), customer.getCustomerName(), type);
		}).filter(obj -> obj != null).forEach(System.out::println);

		System.out.println("------------------- After java 1.8 way 2 ---------------");

		customers.stream().filter(obj -> obj.getCustomerNamePurchases() > 5000).map((customer) -> {
			return new PriorityCustomer(customer.getCustomerId(), customer.getCustomerName(), "GOLD");
		}).forEach(System.out::println);
	}

}
