package com.exilant.day2;

public class EmployeeClient {
public static void main(String[] args) {
	ExilantEmployee ee=new ExilantEmployee();
	ee.salary();
	ee.noOfHours();
	IEmployee.commonUtility();
}
}
