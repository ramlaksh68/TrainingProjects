package com.exilant.day2;

public class ExilantEmployee implements IEmployee,IDepartment{

	@Override
	public void salary() {
		System.out.println("The Salary is decided by the project work");
	}

	@Override
	public void noOfHours() {
		// TODO Auto-generated method stub
		IDepartment.super.noOfHours();
		IEmployee.super.noOfHours();
	}

	@Override
	public void workLocation() {
		System.out.println("Bangalore ");
	}

}
