package com.exilant.day2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

public class FilesReading {
public static void main(String[] args) throws IOException {
	
	System.out.println("---------All files Path -----------");
	Files.list(Paths.get("/Users/ramu.m/Documents/DailyTask")).forEach(System.out::println);;
	
	System.out.println("---------All files Path NAme -----------");
	Files.list(Paths.get(".")).
	map(p->p.getFileName().toString().toUpperCase()).
	filter(fnm->fnm.endsWith("TXT")).
	limit(5).
	forEach(System.out::println);
	
	System.out.println("---------Matched files All files Path NAme -----------");
	Files.list(Paths.get(".")).filter(fnm->fnm.getFileName().toString().endsWith("txt")).filter(file->{
		try(BufferedReader  bire = new BufferedReader(new FileReader(file.toFile()))) {
			return bire.lines().collect(Collectors.toList()).toString().contains("exilant");
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return false;
	}).map(Path::getFileName).forEach(System.out::println);
	
	
}
}
