package com.exilant.day2;

import java.util.Arrays;
import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.stream.DoubleStream;

import static java.util.stream.Collectors.*;
import static java.lang.System.*;
import com.exilant.day1.Customer;

public class GroupingBY {
	public static void main(String[] args) {
		
		List<Customer> customers = Arrays.asList(new Customer(101, "Ramu", 6000d, "Engineer"),
				new Customer(104, "Pooja", 6500d, "Developer"), new Customer(102, "Allahraka", 7500d, "Lead"),
				new Customer(107, "Anuj", 5600d, "Engineer"), new Customer(103, "Siva", 4000d, "Developer"));
		
		DoubleSummaryStatistics sum=customers.stream().mapToDouble(Customer::getCustomerNamePurchases).summaryStatistics();
		System.out.println("Count : "+sum.getCount());
		System.out.println("Max : "+sum.getMax());
		System.out.println("Min : "+sum.getMin());
		System.out.println("Sum : "+sum.getSum());
		System.out.println("Avg : "+sum.getAverage());
		
		customers.stream().collect(groupingBy(Customer::getDesignation)).
		forEach((key,val)->out.println(key+" - "+val.stream().map(Customer::getCustomerName).collect(toList())));;
	
		
		System.out.println("-------------------- Groping by name -------------------");
		customers.stream().map(Customer::getCustomerName).forEach(out::println);
		
		System.out.println("-------------------- Groping by Desgnation with count-------------------");
		customers.stream().collect(groupingBy(Customer::getDesignation,counting())).forEach((key,val)->out.println(key+" - "+val));;
		
		System.out.println("-------------------- Groping by Desgnation with Salary Sum-------------------");
		customers.stream().collect(groupingBy(Customer::getDesignation,summingDouble(Customer::getCustomerNamePurchases))).forEach((key,val)->out.println(key+" - "+val));;
		
		System.out.println("-------------------- Partioning by isAbove5k -------------------");
		customers.stream().collect(partitioningBy(Customer::isAbove5k)).forEach((key,val)->out.println(key+" - "+val));;
		
		System.out.println("-------------------- Partioning by isAbove5k with counting-------------------");
		customers.stream().collect(partitioningBy(Customer::isAbove5k,counting())).forEach((key,val)->out.println(key+" - "+val));;
		
		System.out.println("-------------------- Partioning and GroupBY by isAbove5k with counting-------------------");
		customers.stream().collect(partitioningBy(Customer::isAbove5k,groupingBy(Customer::getDesignation,counting()))).forEach((key,val)->out.println(key+" - "+val));;
		
		System.out.println("--------------------Grouping and Partioning by isAbove5k with counting-------------------");
		customers.stream().collect(groupingBy(Customer::getDesignation,partitioningBy(Customer::isAbove5k,counting()))).forEach((key,val)->out.println(key+" - "+val));;
		
		;
	}
}
