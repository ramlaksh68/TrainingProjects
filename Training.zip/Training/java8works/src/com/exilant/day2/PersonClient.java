package com.exilant.day2;
import static java.lang.System.*;
import java.util.Arrays;
import java.util.List;

public class PersonClient {
public static void main(String[] args) {
	List<Person> persons=Arrays.asList(
			new Person(101,"Goutham")
			,new Person(102,"Sidharth"),
			new Person(103,"Chandini"),
			new Person(104,"Rupa"),
			new Person(105,"ABC")
			);
	
	persons.forEach(new PersonCunsumer()::accept);
	persons.forEach(PersonClient::printCustom);
}


public static void printCustom(Person t) {
	System.out.println("Person id :"+t.getPid()+" ; Person Name :"+t.getName() +"--- BY Person Client-----");
}
}
