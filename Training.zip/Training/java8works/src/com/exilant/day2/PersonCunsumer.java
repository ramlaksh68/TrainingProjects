package com.exilant.day2;

import java.util.function.Consumer;

public class PersonCunsumer implements Consumer<Person>{

	public PersonCunsumer() {
		System.out.println("Count of Object Creation");
	}
	
	@Override
	public void accept(Person t) {
		// TODO Auto-generated method stub
		System.out.println("Person id :"+t.getPid()+" ; Person Name :"+t.getName()+" -----BY Person Consumner-----");
	}

}
