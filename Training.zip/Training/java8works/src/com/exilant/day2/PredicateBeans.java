package com.exilant.day2;
import static java.lang.System.*;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicateBeans {

	
	public static void main(String[] args) {
		Predicate<Person> idGreaterThan=(person)->person.getPid()>102;
		Predicate<Person> idLessThan=(person)->person.getPid()<104;
		Predicate<Person> compound=idLessThan.and(idGreaterThan);
		
			List<Person> persons=Arrays.asList(
				new Person(101,"Goutham")
				,new Person(102,"Sidharth"),
				new Person(103,"Chandini"),
				new Person(104,"Rupa"),
				new Person(105,"ABC")
				);
			out.println("----------- Greater Than ---------");
		persons.stream().filter(idGreaterThan).forEach(out::println);;
		
		out.println("----------- Less Than ---------");
		persons.stream().filter(idLessThan).forEach(out::println);;
		
		out.println("----------- Greater Than && Less Than ---------");
		persons.stream().filter(compound).forEach(out::println);;
	}
}
