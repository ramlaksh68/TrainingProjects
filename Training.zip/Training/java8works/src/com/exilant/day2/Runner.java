package com.exilant.day2;

public class Runner {
	public void excute(WorkerInterface wrkInterface) {
		System.out.println("In Excute Method....");
		wrkInterface.doSomeWork();
	}
}
