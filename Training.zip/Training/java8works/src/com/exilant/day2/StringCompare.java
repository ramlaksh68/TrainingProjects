package com.exilant.day2;
@FunctionalInterface
public interface StringCompare {
	String stringCompare(String text1,String text2);
}
