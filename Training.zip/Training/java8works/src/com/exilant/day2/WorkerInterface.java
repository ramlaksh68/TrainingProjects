package com.exilant.day2;

@FunctionalInterface
public interface WorkerInterface {
  void doSomeWork();
}

