package com.exilant.day2;

public class WorkerInterfaceTest {
								
	public static void main(String[] args) {
		Runner run=new Runner();
		
		
		System.out.println("Before java 1.8");
		
		run.excute(new WorkerInterface() {
			
			@Override
			public void doSomeWork() {
				System.out.println("HI we are doing some work in main");
			}
		});
		
		System.out.println("After java 1.8");
		
		run.excute(()->System.out.println("HI we are doing some work in main"));

	} 
}
