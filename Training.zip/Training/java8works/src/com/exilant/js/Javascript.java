package com.exilant.js;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Javascript {
	public static void main(String[] args) throws FileNotFoundException, ScriptException {
		ScriptEngineManager scriptMger=new ScriptEngineManager();
		ScriptEngine script=scriptMger.getEngineByName("nashorn");
		String name="Anuj";
		Integer result=null;
		script.eval("print('"+name+"')");
		result=(Integer) script.eval("10+20");
		System.out.println("Result is "+result);
	}
}
