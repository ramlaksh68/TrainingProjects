package com.kafka.day2;

public class Client {
public static void main(String[] args) {
	Boolean isAsync=true;
	Producers producers=new Producers(KafkaProperties.TOPICS2, isAsync, "FirstTest");
	producers.start();
	System.out.println("Started Producers");
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	producers.setInterept(true);
}
}
