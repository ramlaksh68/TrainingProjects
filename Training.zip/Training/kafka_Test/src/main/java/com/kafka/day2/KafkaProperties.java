package com.kafka.day2;

public interface KafkaProperties {

	String TOPICS1 ="newTopic";
	String TOPICS2 ="newTopic1";
	String KAFKA_SERVER_URL="localhost";
	int KAFKA_SERVER_PORT=9092;
	int KAFKA_PRODUCER_BUFFER_SIZE=100*1024;
	int CONNECTION_TIMEOUT=1000*10*10;
	String CLIENT_ID="SimpleConsumerDemoClient";
	String PRODUCER_CLIENT_ID = "Client Demo";
	
//only java 9
	//	private String getTopic()
//	{
//		return "";
//	}
}
